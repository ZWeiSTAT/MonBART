#include <Rcpp.h>
#include <iostream>
#include <string>
#include <cstdlib>
#include <math.h>
#include "truncated_normal.h"
#include "info.h"
#include "tree.h"
#include "funs.h"
#include "bd.h"
#include "rrn.h"

using namespace std;
using namespace Rcpp;


// [[Rcpp::export]]
Rcpp::List cmonbartsfm_uadj(
    Rcpp::NumericMatrix R_ix,
    Rcpp::NumericVector R_iy,
    Rcpp::NumericMatrix R_ixp,
    double R_itau,
    double R_inu,
    double R_ilambda,
    double R_ilambda_u,
    double R_ibase,
    double R_ipower,
    int R_ind,
    size_t R_iburn,
    size_t R_im,
    size_t R_imgsize,
    size_t R_inkeeptrain,
    size_t R_inkeeptest,
    size_t R_inkeeptestme,
    size_t R_inkeeptreedraws,
    size_t R_inprintevery
) {
  Rcout<<"This is my mon-Bart code"<<"\n";
  Rprintf("*****Into main of monotonic bart\n");
  //-----------------------------------------------------------
  //random number generation
  GetRNGstate();
  //Rcpp::RNGScope scope;
  //rcpprn gen;
  rrn gen;


  //--------------------------------------------------
  //process args
  //process args
  Rcpp::NumericMatrix xm(R_ix);
  double *x = &xm[0];
  Rcpp::NumericVector yv(R_iy);
  double *y = &yv[0];
  Rcpp::NumericMatrix xpm(R_ixp);

  size_t p = xm.nrow();
  size_t n = xm.ncol();
  size_t np = xpm.ncol();
  double *xp;
  if(np)  xp = &xpm[0];

  double tau = R_itau;
  double nu = R_inu;
  double lambda = R_ilambda;
  double lambda_u=R_ilambda_u;
  double alpha = R_ibase;
  double mybeta = R_ipower;
  size_t nd = R_ind;
  size_t burn = R_iburn;
  size_t m = R_im;
  size_t nm = R_imgsize;

  size_t nkeeptrain = R_inkeeptrain;
  size_t nkeeptest = R_inkeeptest;
  size_t nkeeptestme = R_inkeeptestme;
  size_t nkeeptreedraws = R_inkeeptreedraws;
  size_t printevery = R_inprintevery;


  size_t skiptr,skipte,skipteme,skiptreedraws;
  if(nkeeptrain) {skiptr=nd/nkeeptrain;}
  else skiptr = nd+1;
  if(nkeeptest) {skipte=nd/nkeeptest;}
  else skipte=nd+1;
  if(nkeeptestme) {skipteme=nd/nkeeptestme;}
  else skipteme=nd+1;
  if(nkeeptreedraws) {skiptreedraws = nd/nkeeptreedraws;}
  else skiptreedraws=nd+1;


  //--------------------------------------------------
  /*
   //write out args
   cout << "p: " << p  << endl;
   cout << "n: " << n  << endl;
   cout << "np: " << np  << endl;
   cout << "y, first, last: "  << y[0] << ", " << y[n-1] << endl;
   cout << "nrows xp: " << xpm.nrow()  << endl;
   cout << "ncols xp: " << xpm.ncol()  << endl;
   cout << "first row x: " << x[0] << ", " << x[1] << endl;
   cout << "last x: " << x[(n-1)*p] << ", " << x[(n-1)*p+1] << endl;
   if(np) {
   cout << "first row xp: " << xp[0] << ", " << xp[1] << endl;
   cout << "last xp: " << xp[(np-1)*p] << ", " << xp[(np-1)*p+1] << endl;
   } else {
   cout << "no test observations\n";
   }
   Rprintf("tau: %lf\n",tau);
   Rprintf("nu: %lf\n",nu);
   Rprintf("lambda: %lf\n",lambda);
   Rprintf("tree prior base: %lf\n",alpha);
   Rprintf("tree prior power: %lf\n",mybeta);
   Rprintf("burn (nskip): %ld\n",burn);
   Rprintf("nd (ndpost): %ld\n",nd);
   Rprintf("m (ntree): %ld\n",m);
   Rprintf("nm (mu grid size): %ld\n",nm);
   */

  Rprintf("**********************\n");
  Rprintf("n: %ld\n",n);
  Rprintf("p: %ld\n",p);
  Rprintf("first and last y: %lf, %lf\n",y[0],y[n-1]);
  Rprintf("first row: %lf, %lf\n",x[0],x[p-1]);
  Rprintf("second row: %lf, %lf\n",x[p],x[2*p-1]);
  Rprintf("last row: %lf, %lf\n",x[(n-1)*p],x[n*p-1]);
  if(np) {
    Rprintf("np: %d\n",np);
    Rprintf("first row xp: %lf, %lf\n",xp[0],xp[p-1]);
    Rprintf("second row xp: %lf, %lf\n",xp[p],xp[2*p-1]);
    Rprintf("last row xp : %lf, %lf\n",xp[(np-1)*p],xp[np*p-1]);
  } else {
    Rprintf("no test observations\n");
  }
  Rprintf("tau: %lf\n",tau);
  Rprintf("nu: %lf\n",nu);
  Rprintf("lambda: %lf\n",lambda);
  //Rprintf("sigest: %lf\n",sigest);
  Rprintf("tree prior base: %lf\n",alpha);
  Rprintf("tree prior power: %lf\n",mybeta);
  Rprintf("burn (nskip): %ld\n",burn);
  Rprintf("nd (ndpost): %ld\n",nd);
  Rprintf("m (ntree): %ld\n",m);
  Rprintf("nm (mu grid size): %ld\n",nm);
  Rprintf("*****nkeeptrain,nkeeptest,nkeeptestme, nkeeptreedraws: %d, %d, %d, %d\n",
          nkeeptrain,nkeeptest,nkeeptestme,nkeeptreedraws);
  Rprintf("*****printevery: %d\n",printevery);
  Rprintf("*****skiptr,skipte,skipteme,skiptreedraws: %d,%d,%d,%d\n",
          skiptr,skipte,skipteme,skiptreedraws);
  Rprintf("**********************\n");



  //--------------------------------------------------
  //--------------------------------------------------
  // main code
  //--------------------------------------------------
  //process train data
  double bigval = std::numeric_limits<double>::infinity();
  double miny = bigval; //use range of y to calibrate prior
  double maxy = -bigval;
  sinfo allys;
  for(size_t i=0;i<n;i++) {
    if(y[i]<miny) miny=y[i];
    if(y[i]>maxy) maxy=y[i];
    allys.sy += y[i]; // sum of y
    allys.sy2 += y[i]*y[i]; // sum of y^2
  }
  allys.n = n;
  double ybar = allys.sy/n; //sample mean
  double shat = sqrt((allys.sy2-n*ybar*ybar)/(n-1)); //sample standard deviation
  cout << "ybar,shat: " << ybar << ", " << shat <<  endl;


  //--------------------------------------------------
  //process test data
  dinfo dip; //data information for prediction
  dip.n=np; dip.p=p; dip.x = &xp[0]; dip.y=0;
  Rprintf("dip.n: %ld\n",dip.n);


  //--------------------------------------------------
  // xinfo
  xinfo xi;
  size_t nc=100; //100 equally spaced cutpoints from min to max.
  makexinfo(p,n,&x[0],xi,nc);
  Rprintf("x1 cuts: %lf ... %lf\n",xi[0][0],xi[0][nc-1]);
  if(p>1) {
    Rprintf("xp cuts: %lf ... %lf\n",xi[p-1][0],xi[p-1][nc-1]);
  }

  //--------------------------------------------------
  //trees
  std::vector<tree> t(m);
  for(size_t i=0;i<m;i++) t[i].setm(ybar/m);


  //--------------------------------------------------
  //prior and mcmc
  pinfo pi;
  pi.pbd=1.0; //prob of birth/death move
  pi.pb=.5; //prob of birth given  birth/death

  pi.alpha=alpha; //prior prob a bot node splits is alpha/(1+d)^beta
  pi.mybeta=mybeta;
  pi.tau=tau;
  pi.sigma=shat;

  //***** discrete prior for constained model
  std::vector<double> mg(nm,0.0);  //grid for mu.
  double pridel=3*pi.tau;
  for(size_t i=0;i!=mg.size();i++) mg[i] = -pridel + 2*pridel*(i+1)/(nm+1);
  std::vector<double> pm(nm,0.0);  //prior for mu.

  double sum=0.0;
  for(size_t i=0;i!=mg.size();i++) {
    pm[i] = pn(mg[i],0.0,pi.tau*pi.tau);
    sum += pm[i];
  }
  for(size_t i=0;i!=mg.size();i++)  pm[i] /= sum;
  pi.mg = &mg;
  pi.pm = &pm;

  //--------------------------------------------------
  //dinfo
  double* allfit = new double[n]; //sum of fit of all trees
  for(size_t i=0;i<n;i++) allfit[i]=ybar;
  double* r = new double[n]; //y-(allfit-ftemp) = y-allfit+ftemp
  double* ftemp = new double[n]; //fit of current tree
  dinfo di;
  di.n=n; di.p=p; di.x = &x[0]; di.y=r; //the y will be the residual

  //--------------------------------------------------
  //storage for ouput
  //in sample fit

  //out of sample fit
  double* ppredmean=0; //posterior mean for prediction
  double* fpredtemp=0; //temporary fit vector to compute prediction
  if(dip.n) {
    ppredmean = new double[dip.n];
    fpredtemp = new double[dip.n];
    for(size_t i=0;i<dip.n;i++) ppredmean[i]=0.0;
  }
  //for sigma draw
  double rss;  //residual sum of squares
  double restemp; //a residual

  //--------------------------------------------------
  //return data structures using Rcpp
  //draws
  Rcpp::NumericVector sdraw(nd+burn);
  Rcpp::NumericMatrix trdraw(nkeeptrain,n);
  Rcpp::NumericMatrix tedraw(nkeeptest,np);
  //Save draws for efficiency U vector
  Rcpp::NumericMatrix uvecdraw(nd+burn,n);
  Rcpp::NumericVector uvec_curr(n);
  for(int io = 0; io<n;io++) uvec_curr[io]=1/2;//initial current u to be 1/2,...,1/2
  Rcpp::NumericVector sigmaudraw(nd+burn);
  double sigmau_curr = 1;


  //means
  Rcpp::NumericVector trmean(n); //train
  for(int i=0;i<n;i++) trmean[i]=0.0;
  Rcpp::NumericVector temean(np);
  for(int i=0;i<np;i++) temean[i]=0.0;
  //trees
  std::stringstream treess;  //string stream to write trees to
  treess.precision(10);
  treess << nkeeptreedraws << " " << m << " " << p << endl;

  //--------------------------------------------------
  //mcmc
  cout << "\nMCMC:\n";
  time_t tp;
  int time1 = time(&tp);
  gen.set_df(n+nu);
  size_t trcnt=0;
  size_t tecnt=0;
  size_t temecnt=0;
  size_t treedrawscnt=0;
  bool keeptest,keeptestme,keeptreedraw;

  for(size_t i=0;i<(nd+burn);i++) {

    if(i%printevery==0) cout << "BART-SFM_U_adj i: " << i << ", out of " << nd+burn << endl;
    //draw trees
    for(size_t j=0;j<m;j++) {
      fit(t[j],xi,di,ftemp);
      for(size_t k=0;k<n;k++) {
        allfit[k] = allfit[k]-ftemp[k];
        r[k] = y[k]-allfit[k]+sigmau_curr*uvec_curr[k];//-beta0
      }
      bdc(t[j],xi,di,pi,gen);
      drmuc(t[j],xi,di,pi,gen);
      fit(t[j],xi,di,ftemp);
      for(size_t k=0;k<n;k++) allfit[k] += ftemp[k];
    }
    //draw sigma
    rss=0.0;
    for(size_t k=0;k<n;k++) {
      restemp=y[k]-allfit[k]+sigmau_curr*uvec_curr[k];
      rss += restemp*restemp;}
    pi.sigma = sqrt((nu*lambda + rss)/gen.chi_square());
    sdraw[i]=pi.sigma;

    // // // // // // // // // // // // // // // // // //
    // The followings are code I added for SFM model
    // // // // // // // // // // // // // // // // // //
    // Draw beta_0
    // mu_i_star = Y - Xdes%*%beta_current + Uvec_current
    // beta0_current = rnorm(1, mean = (sigb0_hyper^2*sum(mu_i_star)+sig_v_current^2*mub0_hyper)/(sig_v_current^2+n*sigb0_hyper^2),
    //                       sd = sqrt(sigb0_hyper^2*sig_v_current^2/(sig_v_current^2+n*sigb0_hyper^2)))
    // beta0_post<-c(beta0_post,beta0_current)

    //draw U
    //Update each row i of uvecdraw: juc = 1,...n, is index of U column // -beta0
    for(int juc=0;juc<uvecdraw.ncol();juc++){
      double mu_u=-(y[juc]-allfit[juc])*pow(sigmau_curr,2)/(pow(sigmau_curr,2) + pow(sdraw[i],2));
      double sigma_u=sqrt(pow(sdraw[i],2)*pow(sigmau_curr,2)/(pow(sigmau_curr,2) + pow(sdraw[i],2)));
      int seed = rand();
      uvecdraw(i,juc)=truncated_normal_a_sample(mu_u, sigma_u, 0, seed);

      // // Obtain environment containing function
      // Rcpp::Environment base("package:truncnorm");
      // // Make function callable from C++
      // Rcpp::Function rtruncnorm_r = base["rtruncnorm"];
      // Rcpp::NumericVector res=rtruncnorm_r(
      //   Rcpp::_["n"] = 1,
      //   Rcpp::_["a"]=0,
      //   Rcpp::_["mean"]=mu_u,
      //   Rcpp::_["sd"]=sigma_u);
      // uvecdraw(i,juc)=res[0];
    }
    uvecdraw(i,_)=uvecdraw(i,_)-mean(uvecdraw(i,_))+sigmau_curr*sqrt(2/M_PI);

    // update uvec_curr
    uvec_curr=uvecdraw(i,_);
    // if(i%printevery==0) cout << "ith draw for Uvec: " <<uvec_curr  << endl;

    //draw sigmau
    // same degree freedom as sigma
    //double Su = 1;
    // escala_u=sum(Uvec_current^2)+S_u
    //   sig_u_current<-sqrt(
    //       escala_u/rchisq(1,df=df_u+n)
    double usqsum = 0;
    for(int iu=0; iu<uvec_curr.length();iu++){usqsum =usqsum+pow(uvec_curr[iu],2);}
    //(nu*lambda + rss)/gen.chi_square()
    sigmaudraw[i]= sqrt((nu*lambda_u + usqsum)/gen.chi_square());
    // update current sigma_u
    sigmau_curr = sigmaudraw[i];

    // if(i%printevery==0) cout << "ith draw for sigmau : " <<sigmau_curr<< endl;
    // // // // // // // // // // //
    // #### End of SFM draws
    // // // // // // // // // // //

    if(i>=burn) {
      for(size_t k=0;k<n;k++) trmean[k]+=allfit[k];

      if(nkeeptrain && (((i-burn+1) % skiptr) ==0)) {
        for(size_t k=0;k<n;k++) trdraw(trcnt,k)=allfit[k];
        trcnt+=1;
      }

      keeptest = nkeeptest && (((i-burn+1) % skipte) ==0) && np;
      keeptestme = nkeeptestme && (((i-burn+1) % skipteme) ==0) && np;
      if(keeptest || keeptestme) {
        for(size_t j=0;j<dip.n;j++) ppredmean[j]=0.0;
        for(size_t j=0;j<m;j++) {
          fit(t[j],xi,dip,fpredtemp);
          for(size_t k=0;k<dip.n;k++) ppredmean[k] += fpredtemp[k];
        }
      }
      if(keeptest) {
        for(size_t k=0;k<np;k++) tedraw(tecnt,k)=ppredmean[k];
        tecnt+=1;
      }
      if(keeptestme) {
        for(size_t k=0;k<np;k++) temean[k]+=ppredmean[k];
        temecnt+=1;
      }
      keeptreedraw = nkeeptreedraws && (((i-burn+1) % skiptreedraws) ==0);
      if(keeptreedraw) {
        for(size_t jj=0;jj<m;jj++) treess << t[jj];
        treedrawscnt +=1;
      }
    }
  }
  int time2 = time(&tp);
  cout << "time for loop: " << time2-time1 << endl;
  Rprintf("check counts\n");
  Rprintf("trcnt,tecnt,temecnt,treedrawscnt: %d,%d,%d, %d\n",trcnt,tecnt,temecnt,treedrawscnt);

  for(size_t k=0;k<n;k++) trmean[k]/=nd;
  for(size_t k=0;k<np;k++) temean[k]/=temecnt;

  //--------------------------------------------------
  PutRNGstate();

  //draws of f(x)
  Rcpp::List ret;
  ret["sigma"]=sdraw;
  ret["yhat.train"]=trdraw;
  ret["yhat.test"]=tedraw;
  ret["yhat.train.mean"]=trmean;
  ret["yhat.test.mean"]=temean;
  ret["uvec"]=uvecdraw;
  ret["sigma_u"]=sigmaudraw;

  //trees
  Rcpp::List treesL;
  treesL["trees"]=Rcpp::CharacterVector(treess.str());
  Rcpp::List xiret(xi.size());
  for(size_t i=0;i<xi.size();i++) {
    Rcpp::NumericVector vtemp(xi[i].size());
    std::copy(xi[i].begin(),xi[i].end(),vtemp.begin());
    xiret[i] = Rcpp::NumericVector(vtemp);
  }
  treesL["cutpoints"] = xiret;
  ret["treedraws"] = treesL;

  return ret;

}
