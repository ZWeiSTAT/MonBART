#ifndef GUARD_bd_h
#define GUARD_bd_h

#include "rn.h"
#include "info.h"
#include "tree.h"

bool bd(tree& x, xinfo& xi, dinfo& di, pinfo& pi, rn& gen);
bool bdc(tree& x, xinfo& xi, dinfo& di, pinfo& pi, rn& gen);


#endif
