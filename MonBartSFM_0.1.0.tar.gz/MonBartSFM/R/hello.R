#' @useDynLib MonBartSFM, .registration = TRUE
#' @importFrom Rcpp sourceCpp
"_PACKAGE"


#' This is my first function in package
#' @export
hello <- function() {
  print("Hello, world!")
}
