#' Mon-Bart SFM
#'
#' This is the main function for mon-bart with normal error
#'
#' This function is designed to fit the Monotone BART based Stochastic Frontier
#' Model.
#'
#' @param x.train independent data matrix
#' @param y.train dependent variable vector
#' @param x.test test x
#' @param sigest sigest
#' @param sigdf sigdf
#' @param sigquant sigquant
#' @param sigu_pre_est sigu_pre_est
#' @param sigquant_u sigquant_u
#' @param k k
#' @param power power
#' @param base base
#' @param sigmaf sigmaf
#' @param lambda lambda
#' @param fmean fmean
#' @param ntree number of trees
#' @param ndpost number of posterior samples
#' @param nskip number of burn-in samples
#' @param mgsize mgsize
#' @param nkeeptrain nkeeptrain
#' @param nkeeptest nkeeptest
#' @param nkeeptestmean nkeeptestmean
#' @param nkeeptreedraws nkeeptreedraws
#' @param printevery printevery
#' @import Rcpp
#' @import stats
#' @export
monbartsfm_beta0_uadj=function(
  x.train,y.train, x.test=matrix(0.0,0,0),
  sigest=NA, sigdf=3, sigquant=.90,
  sigu_pre_est=0.5,#apply(res_bayes,2,mean)[4],
  sigquant_u=.05,
  k=2.0,
  power=.8, base=.25, #regular bart is 2,.95
  sigmaf=NA,
  lambda=NA,
  fmean = mean(y.train),
  #fscale = sd(y.train),
  ntree=200,
  ndpost=1000, nskip=100,
  mgsize=50,
  nkeeptrain=ndpost,nkeeptest=ndpost,
  nkeeptestmean=ndpost,
  nkeeptreedraws=ndpost,
  printevery=10
)
{
  require(Rcpp)
  #--------------------------------------------------
  nd = ndpost
  burn = nskip
  #--------------------------------------------------
  #data
  n = length(y.train)
  p = ncol(x.train)
  np = nrow(x.test)
  x = t(x.train)
  xp = t(x.test)
  y.train = (y.train-fmean)#/fscale
  #--------------------------------------------------
  #set  nkeeps for thinning
  if((nkeeptrain!=0) & ((ndpost %% nkeeptrain) != 0)) {
    nkeeptrain=ndpost
    cat('*****nkeeptrain set to ndpost\n')
  }
  if((nkeeptest!=0) & ((ndpost %% nkeeptest) != 0)) {
    nkeeptest=ndpost
    cat('*****nkeeptest set to ndpost\n')
  }
  if((nkeeptestmean!=0) & ((ndpost %% nkeeptestmean) != 0)) {
    nkeeptestmean=ndpost
    cat('*****nkeeptestmean set to ndpost\n')
  }
  if((nkeeptreedraws!=0) & ((ndpost %% nkeeptreedraws) != 0)) {
    nkeeptreedraws=ndpost
    cat('*****nkeeptreedraws set to ndpost\n')
  }

  #--------------------------------------------------
  #sigest
  if(is.na(sigest)) {
    if(p < n) {
      df = data.frame(x.train,y.train)
      lmf = lm(y.train~.,df)
      sigest = summary(lmf)$sigma
    } else {
      sigest = sd(y.train)
    }
  }
  #--------------------------------------------------
  #prior
  nu=sigdf
  if(is.na(lambda)) {
    if(is.na(sigest)) {
      if(p < n) {
        df = data.frame(x.train,y.train)
        lmf = lm(y.train~.,df)
        sigest = summary(lmf)$sigma
      } else {
        sigest = sd(y.train)
      }
    }
    qchi = qchisq(1.0-sigquant,nu)
    lambda = (sigest*sigest*qchi)/nu #lambda parameter for sigma prior
  }

  #prior for sigma_u
  sigest_u=sigu_pre_est
  qchi = qchisq(1.0-sigquant_u,nu)
  lambda_u = (sigest_u*sigest_u*qchi)/nu #lambda parameter for sigma prior



  if(is.na(sigmaf)) {
    tau=(max(y.train)-min(y.train))/(2*k*sqrt(ntree));
  } else {
    tau = sigmaf/sqrt(ntree)
  }
  tau = sqrt(1.467)*tau #adjustment for monotonic constraint
  #--------------------------------------------------
  #call
  res = cmonbartsfm_beta0_uadj(
    R_ix=x,
    R_iy=y.train,
    R_ixp=xp,
    R_itau=tau,
    R_inu=nu,
    R_ilambda=lambda,
    R_ilambda_u=lambda_u,
    R_ibase=base,
    R_ipower=power,
    R_ind=nd,
    R_iburn=burn,
    R_im=ntree,
    R_imgsize=mgsize,
    R_inkeeptrain= nkeeptrain,
    R_inkeeptest=nkeeptest,
    R_inkeeptestme=nkeeptestmean,
    R_inkeeptreedraws=nkeeptreedraws,
    R_inprintevery=printevery
  )
  res$yhat.train.mean = res$yhat.train.mean+fmean
  res$yhat.train = res$yhat.train+fmean
  res$yhat.test.mean = res$yhat.test.mean+fmean
  res$yhat.test = res$yhat.test+fmean
  res$nkeeptreedraws=nkeeptreedraws


  return(res)
}
